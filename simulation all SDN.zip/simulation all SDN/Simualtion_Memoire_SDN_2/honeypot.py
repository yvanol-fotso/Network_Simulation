import socket
import time

HONEYPOT_IP = '10.0.0.4'
HONEYPOT_PORT = 60

honeypot_log_file = open('honeypot_reception_log.txt', 'w')

def log_honeypot_packet(reception_time, src_ip, response_time=None):
    if response_time:
        honeypot_log_file.write(f"Reception: {reception_time}, Source IP: {src_ip}, Response: {response_time}\n")
    else:
        honeypot_log_file.write(f"Reception: {reception_time}, Source IP: {src_ip}\n")
    honeypot_log_file.flush()

honeypot_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
honeypot_sock.bind((HONEYPOT_IP, HONEYPOT_PORT))

print(f"Honeypot listening on {HONEYPOT_IP}:{HONEYPOT_PORT}")

try:
    while True:
        data, addr = honeypot_sock.recvfrom(512)
        reception_time = time.time()
        log_honeypot_packet(reception_time, addr[0])
        
        response = b'Honeypot received packet'
        honeypot_sock.sendto(response, addr)
        response_time = time.time()
        
        log_honeypot_packet(reception_time, addr[0], response_time)

except KeyboardInterrupt:
    print("Shutting down Honeypot.")
finally:
    honeypot_log_file.close()
    honeypot_sock.close()
