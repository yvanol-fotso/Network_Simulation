import dpkt
import random
import time
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER, set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet
from ryu.lib.packet import ethernet
from ryu.lib.packet import ipv4
from ryu.lib.packet import udp

class DNSMitigationController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(DNSMitigationController, self).__init__(*args, **kwargs)
        self.log_file = open('detection_log.txt', 'w')

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        # Installer une règle de flux par défaut pour envoyer tous les paquets au contrôleur
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER,
                                          ofproto.OFPCML_NO_BUFFER)]
        self.add_flow(datapath, 0, match, actions)

        # Installer des règles pour permettre le trafic ARP
        match = parser.OFPMatch(eth_type=0x0806)
        actions = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match, actions)

        # Installer des règles pour permettre le trafic ICMP
        match = parser.OFPMatch(eth_type=0x0800, ip_proto=1)
        actions = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match, actions)

    def add_flow(self, datapath, priority, match, actions, buffer_id=None):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        if buffer_id:
            mod = parser.OFPFlowMod(datapath=datapath, buffer_id=buffer_id,
                                    priority=priority, match=match,
                                    instructions=inst)
        else:
            mod = parser.OFPFlowMod(datapath=datapath, priority=priority,
                                    match=match, instructions=inst)
        datapath.send_msg(mod)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        start_time = time.time()
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        in_port = msg.match['in_port']

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocols(ethernet.ethernet)[0]

        # Ignore les paquets LLDP pour éviter des boucles de découverte
        if eth.ethertype == 0x88cc:
            return

        if eth.ethertype == 0x0800:  # IPv4
            ip = pkt.get_protocols(ipv4.ipv4)[0]
            if ip.proto == 17:  # UDP
                udp_pkt = pkt.get_protocols(udp.udp)[0]
                if udp_pkt.dst_port == 53:  # DNS
                    dns_pkt = self.parse_dns_packet(msg.data)
                    if dns_pkt and dns_pkt.qr == 1:  # DNS Response
                        is_malicious = self.is_dns_attack(dns_pkt)
                        detection_time = time.time() - start_time
                        allow_packet = random.choice([True, False])
                        self.log_detection(dns_pkt, "malicious" if is_malicious else "benign", detection_time, allow_packet)
                        if is_malicious and not allow_packet:
                            self.redirect_to_honeypot(datapath, in_port, msg.data)
                            return
                        else:
                            # Autoriser le paquet à atteindre sa destination normale
                            match = parser.OFPMatch(in_port=in_port, eth_src=eth.src, eth_dst=eth.dst)
                            actions = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
                            self.add_flow(datapath, 1, match, actions, msg.buffer_id)
                            return

        # Installer une règle de flux pour les paquets non traités pour permettre la communication
        match = parser.OFPMatch(in_port=in_port, eth_dst=eth.dst)
        actions = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match, actions, msg.buffer_id)

    def parse_dns_packet(self, data):
        eth = dpkt.ethernet.Ethernet(data)
        ip = eth.data
        udp = ip.data
        try:
            dns = dpkt.dns.DNS(udp.data)
            return dns
        except dpkt.UnpackError:
            return None

    def is_dns_attack(self, dns_pkt):
        # Détection simplifiée d'une attaque DNS basée sur le TXID
        return 1000 <= dns_pkt.id < 10100

    def log_detection(self, dns_pkt, label, detection_time, allow):
        current_time = time.time()
        self.log_file.write(f"{current_time}, {label}, {detection_time}, {allow}\n")
        self.log_file.flush()

    def redirect_to_honeypot(self, datapath, in_port, data):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        actions = [parser.OFPActionSetField(ipv4_dst="10.0.0.4"),
                   parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        out = parser.OFPPacketOut(datapath=datapath, buffer_id=ofproto.OFP_NO_BUFFER,
                                  in_port=in_port, actions=actions, data=data)
        datapath.send_msg(out)

    def __del__(self):
        self.log_file.close()
