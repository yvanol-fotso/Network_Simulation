import socket
import time

# Configuration du serveur DNS
DNS_SERVER_IP = '10.0.0.3'  # Adresse IP du serveur DNS dans la topologie Mininet
DNS_SERVER_PORT = 53

# Fichier de log pour enregistrer les paquets reçus
log_file = open('dns_reception_log.txt', 'w')

def log_packet(reception_time, src_ip):
    current_time = time.time()
    log_file.write(f"{current_time}, {src_ip}, {reception_time}\n")
    log_file.flush()

# Création du socket UDP pour écouter les paquets DNS
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((DNS_SERVER_IP, DNS_SERVER_PORT))

print(f"DNS Server listening on {DNS_SERVER_IP}:{DNS_SERVER_PORT}")

try:
    while True:
        # Attendre la réception d'un paquet
        data, addr = sock.recvfrom(512)
        reception_time = time.time()
        
        # Enregistrer les informations dans le fichier de log
        log_packet(reception_time, addr[0])
        
        # Répondre au client pour indiquer la réception (facultatif)
        response = b'Packet received'
        sock.sendto(response, addr)

except KeyboardInterrupt:
    print("Shutting down DNS server.")
finally:
    log_file.close()
    sock.close()
