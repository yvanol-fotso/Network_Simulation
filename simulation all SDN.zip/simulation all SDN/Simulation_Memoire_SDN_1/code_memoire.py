from mininet.topo import Topo
from mininet.cli import CLI
from mininet.net import Mininet
from mininet.log import setLogLevel, info
from mininet.node import RemoteController, OVSSwitch

class CustomTopo(Topo):
    def build(self):
        # Adding hosts
        h1 = self.addHost('h1', ip='10.0.0.1')
        h2 = self.addHost('h2', ip='10.0.0.2')
        h3 = self.addHost('h3', ip='10.0.0.3')  # Attacker
        dns = self.addHost('dns', ip='10.0.0.4')
        honeypot = self.addHost('honeypot', ip='10.0.0.5')

        # Adding switches
        s1 = self.addSwitch('s1', protocols='OpenFlow13')
        s2 = self.addSwitch('s2', protocols='OpenFlow13')

        # Creating links
        self.addLink(s1, h1)
        self.addLink(s1, h2)
        self.addLink(s2, h3)
        self.addLink(s1, dns)
        self.addLink(s2, honeypot)

def run():
    topo = CustomTopo()
    net = Mininet(topo=topo, controller=RemoteController, switch=OVSSwitch)

    # Adding controller
    c0 = net.addController('c0', controller=RemoteController, ip='127.0.0.1', port=6633)

    info('*** Starting network\n')
    net.start()
    c0.start()

    info('*** Running CLI\n')
    CLI(net)

    info('*** Stopping network\n')
    net.stop()

if __name__ == '__main__':
    setLogLevel('info')
    run()
