from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER, set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet
from ryu.lib.packet import ethernet
from ryu.lib.packet import ipv4
from ryu.lib.packet import arp
from ryu.lib.packet import icmp
from ryu.lib.packet import udp
#from ryu.lib.packet import dns

class DNSMitigationController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(DNSMitigationController, self).__init__(*args, **kwargs)

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        # Installer une règle de flux par défaut pour envoyer tous les paquets au contrôleur
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER,
                                          ofproto.OFPCML_NO_BUFFER)]
        self.add_flow(datapath, 0, match, actions)

        # Installer des règles pour permettre le trafic ARP
        match = parser.OFPMatch(eth_type=0x0806)
        actions = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match, actions)

        # Installer des règles pour permettre le trafic ICMP
        match = parser.OFPMatch(eth_type=0x0800, ip_proto=1)
        actions = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match, actions)

    def add_flow(self, datapath, priority, match, actions, buffer_id=None):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        if buffer_id:
            mod = parser.OFPFlowMod(datapath=datapath, buffer_id=buffer_id,
                                    priority=priority, match=match,
                                    instructions=inst)
        else:
            mod = parser.OFPFlowMod(datapath=datapath, priority=priority,
                                    match=match, instructions=inst)
        datapath.send_msg(mod)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        in_port = msg.match['in_port']

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocols(ethernet.ethernet)[0]

        # Ignore les paquets LLDP pour éviter des boucles de découverte
        if eth.ethertype == 0x88cc:
            return

        if eth.ethertype == 0x0800:  # IPv4
            ip = pkt.get_protocols(ipv4.ipv4)[0]
            if ip.proto == 17:  # UDP
                udp_pkt = pkt.get_protocols(udp.udp)[0]
                if udp_pkt.dst_port == 53:  # DNS
                    dns_pkt = pkt.get_protocol(dns.dns)
                    if dns_pkt and dns_pkt.qr == 1:  # DNS Response
                        if self.is_dns_attack(dns_pkt):
                            self.logger.info("Malicious DNS packet detected from %s to %s", ip.src, ip.dst)
                            self.redirect_to_honeypot(datapath, in_port, msg.data)
                            return

        # Installer une règle de flux pour les paquets non traités pour permettre la communication
        match = parser.OFPMatch(in_port=in_port, eth_dst=eth.dst)
        actions = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match, actions, msg.buffer_id)

    def is_dns_attack(self, dns_pkt):
        # Détection simplifiée d'une attaque DNS basée sur le TXID
        return 1000 <= dns_pkt.id < 10000

    def redirect_to_honeypot(self, datapath, in_port, data):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        actions = [parser.OFPActionSetField(ipv4_dst="10.0.0.4"),
                   parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        out = parser.OFPPacketOut(datapath=datapath, buffer_id=ofproto.OFP_NO_BUFFER,
                                  in_port=in_port, actions=actions, data=data)
        datapath.send_msg(out)

