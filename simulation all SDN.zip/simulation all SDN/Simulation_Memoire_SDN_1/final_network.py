#!/usr/bin/env python

"""
This is a simple example that demonstrates multiple links
between nodes.
"""

from mininet.cli import CLI
from mininet.log import setLogLevel
from mininet.net import Mininet
from mininet.topo import Topo
from mininet.node import Controller,OVSSwitch

class CustomTopo(Topo):
    def build(self):
        # Adding hosts
        h1 = self.addHost('h1', ip='10.0.0.1')
        h2 = self.addHost('h2', ip='10.0.0.2')
        h3 = self.addHost('attaker', ip='10.0.0.3')  # Attacker
        dns = self.addHost('dns', ip='10.0.0.4')
        honeypot = self.addHost('honeypot', ip='10.0.0.5')

        # Adding switches
        s1 = self.addSwitch('s1', protocols='OpenFlow13')
        s2 = self.addSwitch('s2', protocols='OpenFlow13')

        # Creating links
        self.addLink(s1, h1, intfName1='s1-eth1', intfName2='h1-eth0')
        self.addLink(s1, h2, intfName1='s1-eth2', intfName2='h2-eth0')
        self.addLink(s2, h3, intfName1='s2-eth1', intfName2='h3-eth0')
        self.addLink(s1, dns, intfName1='s1-eth3', intfName2='dns-eth0')
        self.addLink(s2, honeypot, intfName1='s2-eth2', intfName2='honeypot-eth0')
        self.addLink(s1, s2, intfName1='s1-eth4', intfName2='s2-eth3')  # Adding link between switches

def run():
    topo = CustomTopo()
    net = Mininet(topo=topo, controller = Controller,switch = OVSSwitch,waitConnected=True)
    net.start()
    CLI(net)
    net.stop()

if __name__ == '__main__':
    setLogLevel('info')
    run()
