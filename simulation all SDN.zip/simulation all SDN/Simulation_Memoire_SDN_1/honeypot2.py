from scapy.all import sniff, send, IP, UDP, DNS

def respond_to_attacker(packet):
    attacker_ip = packet[IP].src  # L'adresse IP de l'attaquant
    original_dst_ip = packet[IP].dst  # L'adresse IP d'origine de la destination

    # Répondre à l'attaquant avec le paquet modifié
    reply_packet = packet.copy()
    reply_packet[IP].dst = attacker_ip
    reply_packet[IP].src = original_dst_ip

    if UDP in reply_packet:
        reply_packet[UDP].sport, reply_packet[UDP].dport = reply_packet[UDP].dport, reply_packet[UDP].sport
    
    print(f"Répondant à {attacker_ip} depuis {original_dst_ip}")
    send(reply_packet, verbose=0)

def honeypot(packet):
    if packet.haslayer(IP) and packet.haslayer(UDP) and packet.haslayer(DNS):
        if packet[DNS].qr == 1:  # Si c'est une réponse DNS
            print(f"Paquet DNS redirigé reçu de {packet[IP].src} vers {packet[IP].dst}")
            respond_to_attacker(packet)
        else:
            print(f"Paquet reçu n'est pas une réponse DNS: {packet.summary()}")
    else:
        print(f"Paquet non DNS ou couches manquantes: {packet.summary()}")

if __name__ == "__main__":
    print("Démarrage du honeypot DNS...")
    #sniff(filter="ip dst 10.0.0.4 and udp port 53",prn=honeypot)
    sniff(prn=honeypot)
