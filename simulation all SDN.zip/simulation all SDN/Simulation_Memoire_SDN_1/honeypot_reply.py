from scapy.all import sniff, IP, UDP, DNS, send,DNSQR,DNSRR

# Adresses IP des différents éléments de la topologie
DNS_IP = "10.0.0.3"
ATTACKER_IP = "10.0.0.1"

def create_fake_dns_response(query_name):
    # Créer un nouveau paquet DNS falsifié avec Scapy
    fake_dns_response = IP(dst=ATTACKER_IP, src=DNS_IP)/UDP(dport=53)/DNS(
        id=1010,
        qr=1,  # Indiquer qu'il s'agit d'une réponse
        aa=1,  # Authoritative Answer
        qd=DNSQR(qname=query_name),
        an=DNSRR(rrname=query_name, ttl=86400, rdata="192.0.2.123")
    )
    return fake_dns_response

def respond_to_attacker(packet):
    # Extraire le nom de la requête DNS du paquet reçu
    #query_name = packet[DNS].qd.qname.decode('utf-8')
    query_name = "www.bank.com"
    # Créer une fausse réponse DNS pour cette requête
    fake_response = create_fake_dns_response(query_name)
    # Envoyer la fausse réponse à l'attaquant
    send(fake_response, verbose=0)

def honeypot(packet):
    #print(f"Paquet redirigé reçu de {packet[IP].src} vers {packet[IP].dst}") ## n'est pas bon car le packet entrant et encoder et formater impossible d'acceder au couche 
    respond_to_attacker(packet)
    
    print("Packet redirigé vers l'attaquant ")

if __name__ == "__main__":
    print("Démarrage du honeypot...")
    # Sniffer tous les paquets et les rediriger vers la fonction honeypot
    sniff(filter="ip dst 10.0.0.4 and udp port 53",prn=honeypot)
