from mininet.net import Mininet
from mininet.node import Controller, OVSSwitch,RemoteController
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.topo import Topo

def runMultiLink():
    "Create and run multiple link network"
    topo = CustomTopo()
    #net = Mininet(topo=topo, controller=Controller, switch=OVSSwitch, autoSetMacs=True)
    net = Mininet(topo=topo, controller=lambda name: RemoteController(name, ip='0.0.0.0',port=6653), switch=OVSSwitch, autoSetMacs=True) #port et ip par defaut du controlleur ryu quant on a pas preciser lors du demarrageEe
    net.start()
    
    # Display node connections
    info('*** Dumping host connections\n')
    for host in net.hosts:
        info(f'{host.name} -> {host.cmd("ifconfig")}\n')

    CLI(net)
    net.stop()

class CustomTopo(Topo):
    "Custom topology with multiple links"

    def build(self):
        # Adding hosts
        attaker = self.addHost('attaker',ip='10.0.0.1')
        h2 = self.addHost('h2',ip='10.0.0.2')
        dns = self.addHost('dns',ip='10.0.0.3')
        honeypot = self.addHost('honeypot',ip='10.0.0.4')
        s1 = self.addSwitch('s1')

        # Creating links
        self.addLink(s1, attaker)
        self.addLink(s1, h2)
        self.addLink(s1, dns)
        self.addLink(s1, honeypot)

if __name__ == '__main__':
    setLogLevel('info')
    runMultiLink()
