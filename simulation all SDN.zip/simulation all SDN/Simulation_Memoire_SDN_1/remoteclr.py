from mininet.net import Mininet
from mininet.node import RemoteController, OVSSwitch
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.topo import Topo
from mininet.link import TCLink

class CustomTopo(Topo):
    def build(self):
        # Adding hosts
        h1 = self.addHost('h1', ip='10.0.0.1')
        h2 = self.addHost('h2', ip='10.0.0.2')
        h3 = self.addHost('h3', ip='10.0.0.3')  # Attacker
        dns = self.addHost('dns', ip='10.0.0.4')
        honeypot = self.addHost('honeypot', ip='10.0.0.5')

        # Adding switches
        s1 = self.addSwitch('s1', protocols='OpenFlow13')
        s2 = self.addSwitch('s2', protocols='OpenFlow13')

        # Creating links
        self.addLink(s1, h1)
        self.addLink(s1, h2)
        self.addLink(s2, h3)
        self.addLink(s1, dns)
        self.addLink(s2, honeypot)
        self.addLink(s1, s2)  # Adding link between switches

def run():
    topo = CustomTopo()
    
    # Replace the IP address and port with the IP address and port of your remote controller
    remote_ip = '127.0.0.1'
    remote_port = 6633  # Use 6653 if using ONOS

    net = Mininet(topo=topo, controller=lambda name: RemoteController(name, ip=remote_ip, port=remote_port), switch=OVSSwitch, autoSetMacs=True, link=TCLink)

    info('*** Starting network\n')
    net.build()
    net.start()

    # Display node connections
    info('*** Dumping host connections\n')
    for host in net.hosts:
        info(f'{host.name} -> {host.cmd("ifconfig")}\n')

    info('*** Running CLI\n')
    CLI(net)

    info('*** Stopping network\n')
    net.stop()

if __name__ == '__main__':
    setLogLevel('info')
    run()
