import dpkt
import random
import time
import math
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER, set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet, ethernet, ipv4, udp

class DNSMitigationController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(DNSMitigationController, self).__init__(*args, **kwargs)
        self.log_file = open('detection_log.txt', 'w')
        self.honeypot_ip = "10.0.0.4"
        self.redirection_probability = 0.7
        self.detection_accuracy = 0.8

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        # Flux par défaut : envoyer tous les paquets au contrôleur
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, ofproto.OFPCML_NO_BUFFER)]
        self.add_flow(datapath, 0, match, actions)

        # Flux pour le trafic ARP
        match_arp = parser.OFPMatch(eth_type=0x0806)
        actions_arp = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match_arp, actions_arp)

        # Flux pour le trafic ICMP
        match_icmp = parser.OFPMatch(eth_type=0x0800, ip_proto=1)
        actions_icmp = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match_icmp, actions_icmp)

    def add_flow(self, datapath, priority, match, actions, buffer_id=None):
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        mod = parser.OFPFlowMod(datapath=datapath, priority=priority, match=match, 
                                instructions=inst, buffer_id=buffer_id or ofproto.OFP_NO_BUFFER)
        datapath.send_msg(mod)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto
        in_port = msg.match['in_port']

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocols(ethernet.ethernet)[0]

        # Ignorer les paquets LLDP pour éviter les boucles
        if eth.ethertype == 0x88cc:
            return

        # Gestion des paquets IPv4
        if eth.ethertype == 0x0800:
            ip = pkt.get_protocols(ipv4.ipv4)[0]

            if ip.proto == 17:  # UDP
                udp_pkt = pkt.get_protocols(udp.udp)[0]

                if udp_pkt.dst_port == 53:  # DNS
                    dns_pkt = self.parse_dns_packet(msg.data)

                    if dns_pkt and dns_pkt.qr == 1:  # Réponse DNS
                        is_malicious = self.is_dns_attack(dns_pkt)
                        detection_result = self.simulate_detection(is_malicious)

                        # Redirection vers le honeypot si nécessaire
                        if detection_result == "malicious":
                            if random.random() < self.redirection_probability:
                                self.redirect_to_honeypot(datapath, in_port, msg.data)
                                return
                        else:
                            # Installer une règle pour autoriser le trafic normal
                            match = parser.OFPMatch(in_port=in_port, eth_src=eth.src, eth_dst=eth.dst)
                            actions = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
                            self.add_flow(datapath, 1, match, actions, msg.buffer_id)
                            return

    def parse_dns_packet(self, data):
        try:
            eth = dpkt.ethernet.Ethernet(data)
            ip = eth.data
            udp = ip.data
            dns = dpkt.dns.DNS(udp.data)
            return dns
        except (dpkt.UnpackError, AttributeError):
            return None

    def is_dns_attack(self, dns_pkt):
        return 1000 <= dns_pkt.id <= 1500

    def simulate_detection(self, is_attack):
        prob = random.random()
        if is_attack:
            return "malicious" if prob < self.detection_accuracy else "benign"
        return "benign"

    def redirect_to_honeypot(self, datapath, in_port, data):
        parser = datapath.ofproto_parser
        actions = [parser.OFPActionSetField(ipv4_dst=self.honeypot_ip),
                   parser.OFPActionOutput(datapath.ofproto.OFPP_NORMAL)]
        out = parser.OFPPacketOut(datapath=datapath, in_port=in_port,
                                  actions=actions, data=data,
                                  buffer_id=datapath.ofproto.OFP_NO_BUFFER)
        datapath.send_msg(out)

    def __del__(self):
        self.log_file.close()
