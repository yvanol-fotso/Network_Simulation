import dpkt
import socket
import random
import time
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER, set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet, ethernet, ipv4, udp

class DNSMitigationController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(DNSMitigationController, self).__init__(*args, **kwargs)
        self.honeypot_ip = "10.0.0.4"  # IP du honeypot
        self.dns_server_ip = "10.0.0.3"  # IP du serveur DNS légitime
        self.detection_accuracy = 0.9  # Précision de 90%
        self.log_file = open('detection_log.txt', 'w')
        self.log_file.write("Timestamp, TXID, PredictedLabel, ActualLabel, Decision\n")

    # @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    # def switch_features_handler(self, ev):
    #     """Configuration initiale du switch."""
    #     datapath = ev.msg.datapath
    #     parser = datapath.ofproto_parser
    #     ofproto = datapath.ofproto

    #     # Flux par défaut : envoyer tous les paquets au contrôleur
    #     match = parser.OFPMatch()
    #     actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, ofproto.OFPCML_NO_BUFFER)]
    #     self.add_flow(datapath, 0, match, actions)


    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        """Configuration initiale du switch."""
        datapath = ev.msg.datapath
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        # Flux par défaut : envoyer tous les paquets au contrôleur
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, ofproto.OFPCML_NO_BUFFER)]
        self.add_flow(datapath, 0, match, actions)

        # Flux pour le trafic ARP
        match_arp = parser.OFPMatch(eth_type=0x0806)
        actions_arp = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match_arp, actions_arp)

        # Flux pour le trafic ICMP
        match_icmp = parser.OFPMatch(eth_type=0x0800, ip_proto=1)
        actions_icmp = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match_icmp, actions_icmp)

    def add_flow(self, datapath, priority, match, actions):
        """Ajoute une règle de flux au switch."""
        parser = datapath.ofproto_parser
        inst = [parser.OFPInstructionActions(datapath.ofproto.OFPIT_APPLY_ACTIONS, actions)]
        mod = parser.OFPFlowMod(datapath=datapath, priority=priority, match=match, instructions=inst)
        datapath.send_msg(mod)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        """Gère les paquets entrants."""
        msg = ev.msg
        datapath = msg.datapath
        in_port = msg.match['in_port']

        print(f"Received packet from datapath {datapath.id} on port {in_port}")

        pkt = packet.Packet(msg.data)

        eth = pkt.get_protocol(ethernet.ethernet)
        if eth.ethertype == 0x0800:  # IPv4
            ip = pkt.get_protocol(ipv4.ipv4)
            if ip.proto == 17:  # UDP
                udp_pkt = pkt.get_protocol(udp.udp)
                if udp_pkt.dst_port == 53:  # DNS
                    dns_pkt = self.parse_dns_packet(msg.data)
                    if dns_pkt and dns_pkt.qr == 1:  # Réponse DNS
                        txid = dns_pkt.id  # On log le TXID
                        actual_label = self.get_actual_label(dns_pkt)  # Label réel selon le paquet DNS
                        predicted_label = self.classify_packet(actual_label)  # Classification aléatoire
                        print(actual_label)
                        print("\n")
                        print(predicted_label)
                        
                        #print(dns_pkt.an)
                        
                        # Décision basée sur la classification
                        if predicted_label == "malicious":
                            self.redirect_to_honeypot(datapath, in_port, msg.data)
                            decision = "redirected to honeypot"
                        else:
                            self.forward_to_dns(datapath, in_port, msg.data)
                            decision = "forwarded to DNS"

                        # Journalisation de la décision
                        timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
                        self.log_file.write(
                            f"{timestamp}, {txid}, {predicted_label}, {actual_label}, {decision}\n"
                        )
                        self.log_file.flush()

    def get_actual_label(self, dns_pkt):
        """Détermine le label réel en analysant le contenu du paquet DNS."""
        # Liste des domaines et IPs suspects
        #suspicious_domains = ["malicious.com", "phishing-site.org"]
        suspicious_ips = ["192.168.1.100", "10.0.0.99"]

        # Analyse les réponses DNS dans le paquet
        if dns_pkt.an:
            for answer in dns_pkt.an:
                # Vérifie si le domaine ou l'IP correspond à quelque chose de suspect
                #if answer.name.decode() in suspicious_domains or answer.rdata in suspicious_ips:
                #if answer.name in suspicious_domains or answer.rdata in suspicious_ips:
                decode_ip = dpkt.utils.inet_to_str(answer.rdata)
                #if answer.rdata in suspicious_ips:
                if decode_ip in suspicious_ips:
                    return "malicious"

        # Si rien de suspect n'est détecté
        return "benign"

    def classify_packet(self, actual_label):
        """Classifie le paquet avec une précision de 90%."""
        if actual_label == "malicious":
            return "malicious" if random.random() < self.detection_accuracy else "benign"
        else:
            return "benign" if random.random() < self.detection_accuracy else "malicious"

    # def redirect_to_honeypot(self, datapath, in_port, data):
    #     """Redirige le paquet vers le honeypot."""
    #     parser = datapath.ofproto_parser
    #     actions = [
    #         parser.OFPActionSetField(ipv4_dst=self.honeypot_ip),
    #         parser.OFPActionOutput(datapath.ofproto.OFPP_NORMAL)
    #     ]
    #     out = parser.OFPPacketOut(
    #         datapath=datapath,
    #         buffer_id=datapath.ofproto.OFP_NO_BUFFER,
    #         in_port=in_port,
    #         actions=actions,
    #         data=data
    #     )
    #     datapath.send_msg(out)

   
    # def redirect_to_honeypot(self, datapath, in_port, data):
    #     """Redirige le paquet vers le honeypot avec une règle de flux de haute priorité."""
    #     parser = datapath.ofproto_parser

    #     # Ajouter une nouvelle règle de flux avec une priorité élevée pour rediriger vers le honeypot
    #     match = parser.OFPMatch(eth_type=0x0800, ipv4_dst=self.dns_server_ip)  # Match sur les paquets destinés au serveur DNS
    #     actions = [
    #         parser.OFPActionSetField(ipv4_dst=self.honeypot_ip),  # Changer la destination vers le honeypot
    #         parser.OFPActionOutput(datapath.ofproto.OFPP_NORMAL)  # Envoyer au port normal
    #     ]
    #     self.add_flow(datapath, 100, match, actions)  # Priorité 100 pour la redirection vers le honeypot

    #     # Envoyer le paquet au honeypot
    #     out = parser.OFPPacketOut(
    #         datapath=datapath,
    #         buffer_id=datapath.ofproto.OFP_NO_BUFFER,
    #         in_port=in_port,
    #         actions=actions,
    #         data=data
    #     )
    #     datapath.send_msg(out)



    def redirect_to_honeypot(self, datapath, in_port, data):
        """Redirige le paquet vers le honeypot avec une priorité élevée."""
        parser = datapath.ofproto_parser
        # Correspondance : paquets IPv4, UDP, destinés au serveur DNS légitime sur le port 53
        # Correspondance sur le trafic DNS (port UDP 53) destiné au serveur DNS légitime
        match = parser.OFPMatch(
              eth_type=0x0800,  # IPv4
              ip_proto=17,      # UDP
              ipv4_dst=self.dns_server_ip, 
              udp_dst=53
        )

        # Actions : rediriger le trafic vers le honeypot
        actions = [
              parser.OFPActionSetField(ipv4_dst=self.honeypot_ip),  # Modifier la destination IP
              parser.OFPActionOutput(datapath.ofproto.OFPP_CONTROLLER)  # Envoyer au contrôleur
        ]

        # Ajouter une règle de flux avec une priorité élevée pour garantir l’application
        self.add_flow(datapath, priority=100, match=match, actions=actions)
        self.logger.info("Flow installed to redirect DNS traffic to honeypot.")


        # Envoyer le paquet directement au honeypot
        out = parser.OFPPacketOut(
            datapath=datapath,
            buffer_id=datapath.ofproto.OFP_NO_BUFFER,
            in_port=in_port,
            actions=actions,
            data=data
        )
        datapath.send_msg(out)
        self.logger.info("Packet sent to honeypot.")




    def forward_to_dns(self, datapath, in_port, data):
        """Transmet le paquet au serveur DNS légitime."""
        parser = datapath.ofproto_parser
        actions = [
            # parser.OFPActionSetField(ipv4_dst=self.dns_server_ip),
            #JE TESTE POUR VOIR SI D'ABORD LE FIHCIER HONEYPOT PEUT ECOUTER LES PACKET RECU
            parser.OFPActionSetField(ipv4_dst=self.honeypot_ip),
            parser.OFPActionOutput(datapath.ofproto.OFPP_NORMAL)
        ]
        out = parser.OFPPacketOut(
            datapath=datapath,
            buffer_id=datapath.ofproto.OFP_NO_BUFFER,
            in_port=in_port,
            actions=actions,
            data=data
        )
        datapath.send_msg(out)

    def parse_dns_packet(self, data):
        """Analyse un paquet DNS avec dpkt."""
        eth = dpkt.ethernet.Ethernet(data)
        if isinstance(eth.data, dpkt.ip.IP):
            ip_pkt = eth.data
            if isinstance(ip_pkt.data, dpkt.udp.UDP):
                udp_pkt = ip_pkt.data
                if udp_pkt.dport == 53:
                    try:
                        return dpkt.dns.DNS(udp_pkt.data)
                    except (dpkt.UnpackError, ValueError):
                        self.logger.error("Erreur de décodage du paquet DNS.")
        return None

    def __del__(self):
        """Ferme le fichier log."""
        self.log_file.close()
