import dpkt

def decode_rdata(dns_answers):
    """Décoder les rdata des réponses DNS et les afficher."""
    decoded_answers = []
    
    for answer in dns_answers:
        # Vérifie le type de l'enregistrement DNS
        if answer.type == dpkt.dns.DNS_A:
            # Si c'est un enregistrement A, décode l'adresse IP
            decoded_ip = dpkt.utils.inet_to_str(answer.rdata)
            decoded_answers.append(f"A: {decoded_ip}")
        elif answer.type == dpkt.dns.DNS_CNAME:
            # Si c'est un enregistrement CNAME, décode le nom
            decoded_name = answer.rdata.decode('utf-8')
            decoded_answers.append(f"CNAME: {decoded_name}")
        else:
            # Autres types d'enregistrements (par exemple, MX, TXT, etc.)
            decoded_answers.append(f"Type: {answer.type}, rdata: {answer.rdata}")
    
    return decoded_answers

# Exemple d'utilisation
# dns_pkt.an est supposé être la liste des enregistrements de réponse
dns_answers = dns_pkt.an  # Assurez-vous que dns_pkt est correctement défini
decoded_results = decode_rdata(dns_answers)

# Affiche les résultats
for result in decoded_results:
    print(result)
