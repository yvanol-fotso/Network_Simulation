############# ne marche pas n'ecoute pas les packet il faut calquer sur pour le DNS qui ecoute jusqu'a Marche ############################################
############# Et deplus il faut que c'est pour chaque paquet que on repond et 'on que on appel la fonction la ecoute et apres ce qui recoit ##############

# from scapy.all import sniff, send, IP, UDP, DNS, DNSQR, DNSRR
# import time

# def log_honeypot_packet(packet):
#     """Journalise les paquets DNS reçus avec horodatage et information de la requête."""
#     timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
#     src_ip = packet[IP].src  # Adresse IP de l'attaquant
#     qname = packet[DNSQR].qname.decode() if DNSQR in packet else "unknown"  # Domaine demandé

#     # Journalisation de la requête
#     with open('honeypot_log.txt', 'a') as log_file:
#         log_file.write(f"{timestamp}, Source IP: {src_ip}, Domaine: {qname}\n")
#     print(f"Requête reçue: {timestamp}, Source IP: {src_ip}, Domaine: {qname}")

# def fake_dns_response(packet):
#     """Génère et envoie une réponse DNS factice à l'attaquant."""
#     if DNSQR in packet:
#         # Construire une réponse DNS factice
#         response = IP(dst=packet[IP].src, src=packet[IP].dst) / \
#                    UDP(dport=packet[UDP].sport, sport=53) / \
#                    DNS(id=packet[DNS].id, qr=1, aa=1, qd=packet[DNS].qd,
#                        an=DNSRR(rrname=packet[DNSQR].qname, ttl=300, rdata="10.0.0.4"))  # IP du honeypot

#         # Envoyer la réponse DNS factice
#         send(response, verbose=0)
#         print(f"Réponse factice envoyée à {packet[IP].src} pour {packet[DNSQR].qname.decode()}")

# def handle_packet(packet):
#     """Gère les paquets DNS en journalisant et en envoyant une réponse factice."""
#     log_honeypot_packet(packet)  # Journalise le paquet reçu
#     fake_dns_response(packet)  # Envoie une réponse factice

# def start_sniffing(interface="honeypot-eth0"):
#     """Capture les paquets DNS sur l'interface du honeypot."""
#     print(f"Démarrage de la capture DNS sur l'interface {interface}...")
#     sniff(iface=interface, filter="udp port 53", prn=handle_packet, store=False)

# if __name__ == "__main__":
#     start_sniffing()  # Démarre la capture sur l'interface honeypot-eth0



#########################################################################################
###################### New #############################################################



from scapy.all import sniff, send, IP, UDP, DNS, DNSQR, DNSRR
import time
import socket  # Pour convertir en IP lisible

# Liste d'IPs suspectes pour la détection
SUSPICIOUS_IPS = ["192.168.1.100", "10.0.0.99"]

def extract_label_from_packet(packet):
    """Détermine le label à partir de l'IP retournée dans la réponse DNS."""
    if DNSRR in packet:
        rdata = packet[DNSRR].rdata  # Extraction de l'IP retournée

        # Convertir en format lisible (IP string)
        ip_address = rdata if isinstance(rdata, str) else socket.inet_ntoa(rdata)

        # Vérifier si l'IP est dans la liste des IPs suspectes
        if ip_address in SUSPICIOUS_IPS:
            return "malicious"
        else:
            return "benign"
    return "unknown"  # Si aucune réponse DNS valide n'est présente

def log_honeypot_packet(packet):
    """Journalise les paquets DNS avec horodatage, TXID et label extrait."""
    if DNS in packet and packet[DNS].qr == 1:  # Vérifie si c'est une réponse DNS
        timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
        txid = packet[DNS].id  # Extraction du TXID
        rdata = packet[DNSRR].rdata if DNSRR in packet else "N/A"  # IP retournée
        label = extract_label_from_packet(packet)  # Extraction du label depuis le paquet

        # Enregistrement des informations dans le fichier de journalisation
        with open('honeypot_log.txt', 'a') as log_file:  # Nom changé ici
            log_file.write(f"{timestamp}, {txid}, {label}, {rdata}\n")

        print(f"Packet logué: {timestamp}, TXID: {txid}, Label: {label}, IP: {rdata}")

def fake_dns_response(packet):
    """Génère et envoie une réponse DNS factice à l'attaquant."""
    if DNSQR in packet:
        # Construire une réponse DNS factice avec l'IP du honeypot
        response = (
            IP(dst=packet[IP].src, src=packet[IP].dst) /
            UDP(dport=packet[UDP].sport, sport=53) /
            DNS(
                id=packet[DNS].id, qr=1, aa=1, qd=packet[DNS].qd,
                an=DNSRR(rrname=packet[DNSQR].qname, ttl=300, rdata="10.0.0.4")  # IP factice
            )
        )

        # Envoyer la réponse DNS factice
        send(response, verbose=0)
        print(f"Réponse factice envoyée à {packet[IP].src} pour {packet[DNSQR].qname.decode()}")

def handle_packet(packet):
    """Gère les paquets DNS en journalisant et en envoyant une réponse factice."""
    log_honeypot_packet(packet)  # Journalise le paquet
    fake_dns_response(packet)  # Envoie une réponse factice

def start_sniffing(interface="honeypot-eth0"):
    """Capture des paquets DNS sur l'interface du honeypot."""
    print(f"Démarrage de la capture DNS sur l'interface {interface}...")
    sniff(iface=interface, filter="udp port 53", prn=handle_packet, store=False)

if __name__ == "__main__":
    start_sniffing()  # Démarre la capture
