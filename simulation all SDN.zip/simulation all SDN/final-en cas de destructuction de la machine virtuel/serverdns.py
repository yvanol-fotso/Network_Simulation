# from scapy.all import sniff, DNS, DNSQR, DNSRR, IP, UDP
# import time

# def log_dns_packet(packet):
#     """Fonction de journalisation des paquets DNS reçus."""
#     if DNS in packet and packet[DNS].qr == 1:  # Vérifie si c'est une réponse DNS
#         timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
#         txid = packet[DNS].id  # Extraction du TXID
#         rdata = packet[DNSRR].rdata if packet[DNSRR].rdata else "N/A"  # Extraction du rdata

#         # Simule un label prédictif aléatoire (pour l'exemple, à ajuster selon ton modèle)
#         predicted_label = "malicious" if rdata in ["192.168.1.100", "10.0.0.99"] else "benign"

#         # Enregistre les informations dans un fichier
#         with open('dns_log.txt', 'a') as log_file:
#             log_file.write(f"{timestamp}, {txid}, {predicted_label}, {rdata}\n")
#         print(f"Packet loggé: {timestamp}, {txid}, {predicted_label}, {rdata}")

# def start_sniffing(interface="eth0"):
#     """Capture des paquets DNS sur l'interface spécifiée."""
#     print("Démarrage de la capture DNS...")
#     sniff(iface=interface, filter="udp port 53", prn=log_dns_packet, store=False)

# if __name__ == "__main__":
#     start_sniffing()  # Remplace 'eth0' par l'interface réseau de ton nœud DNS



#############################################################################################
################## Marche mais je ne veux pas extraiire a le ip comme ces fait ici car ######
################## on utyilise un [malicioux_ip deja fixe or nous somme me corte DNS ########
################## ou c'est pluto les information correcte qui y arrive] ####################


# from scapy.all import sniff, DNS, DNSQR, DNSRR, IP, UDP
# import time

# # Liste d'IP malveillantes connues (à adapter selon ton contexte)
# malicious_ips = ["192.168.1.100", "10.0.0.99"]

# def extract_label_from_packet(packet):
#     """Extrait le label du paquet DNS en fonction de son contenu."""
#     if DNSRR in packet:
#         rdata = packet[DNSRR].rdata  # Extraction de l'adresse IP de la réponse DNS
#         # Détermine le label en fonction de l'IP retournée
#         return "malicious" if rdata in malicious_ips else "benign"
#     return "unknown"  # Si aucune réponse DNS valide n'est présente

# def log_dns_packet(packet):
#     """Journalise les paquets DNS avec horodatage, TXID et label extrait."""
#     if DNS in packet and packet[DNS].qr == 1:  # Vérifie si c'est une réponse DNS
#         timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
#         txid = packet[DNS].id  # Extraction du TXID
#         rdata = packet[DNSRR].rdata if DNSRR in packet else "N/A"  # IP de la réponse
#         label = extract_label_from_packet(packet)  # Extraction du label

#         # Enregistre les informations dans un fichier
#         with open('dns_log.txt', 'a') as log_file:
#             log_file.write(f"{timestamp}, {txid}, {label}, {rdata}\n")
#         print(f"Packet logué: {timestamp}, TXID: {txid}, Label: {label}, IP: {rdata}")

# def start_sniffing(interface="dns-eth0"):
#     """Capture des paquets DNS sur l'interface spécifiée."""
#     print("Démarrage de la capture DNS...")
#     sniff(iface=interface, filter="udp port 53", prn=log_dns_packet, store=False)

# if __name__ == "__main__":
#     # Remplace 'eth0' par l'interface réseau utilisée pour écouter les paquets DNS
#     start_sniffing()



######################################## FINAL ##################################
###################### Mais puis uqe nulle part nous encapsulons #################
############# le label dans la reponse initiale et que meme au ###################
############ niveua du controlleur on sert du rdata pour voir ####################
######### le label a attribuer alors on va faire pareil donc si ##################
######## une reponse est arrivee au DNS avec un rdata /ip malicioux ##############
######## alors ces que ces malvailant mais le probleme ui se pose et #############
####### que au niveau du controleur on a souvent les faut posif et ###############
###### faux negatif d'ou il va falloir vraiment trouver une solution #############
###### pour acceder au label ####################################

##### alors je vais pour cette simulation etudier le rdata si sa appartient ######
###### a la classe ou plage malicioux alors on affecte le label 'malicioux' sinon #
### plus besoin de s'inquieter de la preocupation haut car la journalisation au ###
##### niveau du controlleur nous permettra d'eclairer et savoir le nombre de faux ##
###  positif et faux negatif

# from scapy.all import sniff, DNS, DNSQR, DNSRR, IP, UDP
# import time

# def extract_label_from_packet(packet):
#     """Extrait le label à partir de l'IP retournée dans la réponse DNS."""
#     if DNSRR in packet:
#         rdata = packet[DNSRR].rdata  # Extraction de l'IP retournée
#         return f"Label extrait: {rdata}"  # Simple extraction sans attribution externe
#     return "unknown"  # Si aucune réponse DNS valide n'est présente

# def log_dns_packet(packet):
#     """Journalise les paquets DNS avec horodatage, TXID et label extrait."""
#     if DNS in packet and packet[DNS].qr == 1:  # Vérifie si c'est une réponse DNS
#         timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
#         txid = packet[DNS].id  # Extraction du TXID
#         rdata = packet[DNSRR].rdata if DNSRR in packet else "N/A"  # IP retournée
#         label = extract_label_from_packet(packet)  # Extraction du label depuis le paquet

#         # Enregistrement des informations dans le fichier de journalisation
#         with open('dns_log.txt', 'a') as log_file:
#             log_file.write(f"{timestamp}, {txid}, {label}, {rdata}\n")
#         print(f"Packet logué: {timestamp}, TXID: {txid}, Label: {label}, IP: {rdata}")

# def start_sniffing(interface="dns-eth0"):
#     """Capture des paquets DNS sur l'interface spécifiée."""
#     print(f"Démarrage de la capture DNS sur l'interface {interface}...")
#     sniff(iface=interface, filter="udp port 53", prn=log_dns_packet, store=False)

# if __name__ == "__main__":
#     start_sniffing()  # Démarre la capture sur l'interface dns-eth0


###################################################################################


from scapy.all import sniff, DNS, DNSQR, DNSRR, IP, UDP
import time

# Liste d'IPs suspectes pour la détection
SUSPICIOUS_IPS = ["192.168.1.100", "10.0.0.99"]

def extract_label_from_packet(packet):
    """Détermine le label à partir de l'IP retournée dans la réponse DNS."""
    if DNSRR in packet:
        rdata = packet[DNSRR].rdata  # Extraction de l'IP retournée
        
        # Convertir en format lisible (IP string)
        ip_address = rdata if isinstance(rdata, str) else socket.inet_ntoa(rdata)
        
        # Vérifier si l'IP est dans la liste des IPs suspectes
        if ip_address in SUSPICIOUS_IPS:
            return "malicious"
        else:
            return "benign"
    return "unknown"  # Si aucune réponse DNS valide n'est présente

def log_dns_packet(packet):
    """Journalise les paquets DNS avec horodatage, TXID et label extrait."""
    if DNS in packet and packet[DNS].qr == 1:  # Vérifie si c'est une réponse DNS
        timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
        txid = packet[DNS].id  # Extraction du TXID
        rdata = packet[DNSRR].rdata if DNSRR in packet else "N/A"  # IP retournée
        label = extract_label_from_packet(packet)  # Extraction du label depuis le paquet

        # Enregistrement des informations dans le fichier de journalisation
        with open('dns_log.txt', 'a') as log_file:
            log_file.write(f"{timestamp}, {txid}, {label}, {rdata}\n")
        print(f"Packet logué: {timestamp}, TXID: {txid}, Label: {label}, IP: {rdata}")

def start_sniffing(interface="dns-eth0"):
    """Capture des paquets DNS sur l'interface spécifiée."""
    print(f"Démarrage de la capture DNS sur l'interface {interface}...")
    sniff(iface=interface, filter="udp port 53", prn=log_dns_packet, store=False)

if __name__ == "__main__":
    start_sniffing()  # Démarre la capture sur l'interface dns-eth0
