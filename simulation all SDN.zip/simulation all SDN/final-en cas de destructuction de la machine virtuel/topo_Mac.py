from mininet.net import Mininet
from mininet.node import Controller, OVSSwitch, RemoteController
from mininet.cli import CLI
from mininet.log import setLogLevel, info
from mininet.topo import Topo

def runMultiLink():
    "Create and run multiple link network"
    topo = CustomTopo()
    #autoSetMacs=True
    ###Usage de autoSetMacs : Dans ce cas, vous pouvez laisser autoSetMacs=True, mais il sera en conflit avec les adresses MAC que vous avez définies manuellement. Pour éviter toute confusion, il peut être préférable de le définir sur False.
    net = Mininet(topo=topo, controller=lambda name: RemoteController(name, ip='127.0.0.1', port=6653), switch=OVSSwitch, autoSetMacs=False)
    net.start()
    
    # Display node connections
    info('*** Dumping host connections\n')
    for host in net.hosts:
        info(f'{host.name} -> {host.cmd("ifconfig")}\n')

    CLI(net)
    net.stop()

class CustomTopo(Topo):
    "Custom topology with multiple links"

    def build(self):
        # Adding hosts with MAC addresses
        attaker = self.addHost('attaker', ip='10.0.0.1', mac='00:00:00:00:00:01')
        h2 = self.addHost('h2', ip='10.0.0.2', mac='00:00:00:00:00:02')
        dns = self.addHost('dns', ip='10.0.0.3', mac='00:00:00:00:00:03')
        honeypot = self.addHost('honeypot', ip='10.0.0.4', mac='00:00:00:00:00:04')
        s1 = self.addSwitch('s1')

        # Creating links
        self.addLink(s1, attaker)
        self.addLink(s1, h2)
        self.addLink(s1, dns)
        self.addLink(s1, honeypot)

if __name__ == '__main__':
    setLogLevel('info')
    runMultiLink()
