# # #!/usr/bin/env python

# # from pox.core import core
# # import dpkt
# # import random
# # import time
# # from pox.lib.packet import ethernet, ipv4, udp
# # from pox.lib.addresses import IPAddr
# # from pox.openflow import of

# # log = core.getLogger()

# # class DNSMitigationController(object):
# #     def __init__(self):
# #         core.openflow.addListeners(self)
# #         self.honeypot_ip = IPAddr("10.0.0.4")  # IP du honeypot
# #         self.honeypot_mac = "00:00:00:00:00:04"  # Adresse MAC du honeypot
# #         self.dns_server_ip = IPAddr("10.0.0.3")  # IP du serveur DNS légitime
# #         self.detection_accuracy = 0.9  # Précision de 90%
# #         self.log_file = open('detection_log.txt', 'w')
# #         self.log_file.write("Timestamp, TXID, PredictedLabel, ActualLabel, Decision\n")

# #     def _handle_ConnectionUp(self, event):
# #         """Ajoute des règles de flux lorsque le switch se connecte."""
# #         log.info(f"Connection établie avec le switch {event.dpid}")

# #         # Créer un match pour tout le trafic
# #         match = of.ofp_match()
# #         actions = [of.ofp_action_output(port=of.OFPP_NORMAL)]
        
# #         # Créer une règle de flux
# #         flow_mod = of.ofp_flow_mod()
# #         flow_mod.match = match
# #         flow_mod.idle_timeout = 10  # Timeout pour la règle de flux
# #         flow_mod.actions = actions  # Assigner les actions

# #         # Envoyer la règle de flux au switch
# #         event.connection.send(flow_mod)

# #     def _handle_PacketIn(self, event):
# #         """Gère les paquets entrants dans le contrôleur POX."""
# #         packet = event.parsed
# #         in_port = event.port
# #         datapath = event.connection

# #         if not packet.parsed:
# #             log.warning("Paquet ignoré (non parsé)")
# #             return

# #         # Vérifie si le paquet est un paquet IPv4 et UDP avec une destination DNS
# #         if isinstance(packet.next, ipv4) and packet.next.protocol == udp.UDP_PROTOCOL:
# #             log.debug("Paquet UDP IPv4 reçu, vérification du port DNS.")
# #             ip_packet = packet.next
# #             udp_packet = ip_packet.next
# #             if udp_packet.dstport == 53:  # Port DNS
# #                 dns_pkt = self.parse_dns_packet(udp_packet.payload)
# #                 if dns_pkt and dns_pkt.qr == dpkt.dns.DNS_R:
# #                     txid = dns_pkt.id  # Log TXID
# #                     actual_label = self.get_actual_label(dns_pkt)
# #                     predicted_label = self.classify_packet(actual_label)

# #                     # Journalisation de la décision
# #                     log.info(f"TXID: {txid}, Actual Label: {actual_label}, Predicted Label: {predicted_label}")
# #                     if predicted_label == "malicious":
# #                         self.redirect_to_honeypot(datapath, packet, in_port)
# #                         decision = "redirected to honeypot"
# #                     else:
# #                         self.forward_to_dns(datapath, packet, in_port)
# #                         decision = "forwarded to DNS"

# #                     timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
# #                     self.log_file.write(f"{timestamp}, {txid}, {predicted_label}, {actual_label}, {decision}\n")
# #                     self.log_file.flush()
# #                 else:
# #                     log.debug("Paquet DNS non valide ou non parsé correctement.")
# #             else:
# #                 log.debug("Paquet UDP non destiné au port DNS (53).")

# #     def get_actual_label(self, dns_pkt):
# #         """Détermine si le paquet DNS est malveillant ou légitime."""
# #         suspicious_ips = ["192.168.1.100", "10.0.0.99"]

# #         if dns_pkt.an:
# #             for answer in dns_pkt.an:
# #                 decode_ip = dpkt.utils.inet_to_str(answer.ip)
# #                 if decode_ip in suspicious_ips:
# #                     return "malicious"
# #         return "benign"

# #     def classify_packet(self, actual_label):
# #         """Classifie le paquet avec une précision de 90%."""
# #         if actual_label == "malicious":
# #             return "malicious" if random.random() < self.detection_accuracy else "benign"
# #         else:
# #             return "benign" if random.random() < self.detection_accuracy else "malicious"

# #     def redirect_to_honeypot(self, datapath, packet, in_port):
# #         """Redirige les paquets DNS malveillants vers le honeypot."""
# #         # Modifier l'adresse IP de destination du paquet pour qu'il soit redirigé vers le honeypot
# #         actions = [
# #             of.ofp_action_dl_addr.set_dst(self.honeypot_mac),  # Adresse MAC du honeypot
# #             of.ofp_action_nw_addr.set_dst(self.honeypot_ip),   # Adresse IP du honeypot
# #             of.ofp_action_output(port=of.OFPP_NORMAL)
# #         ]
# #         msg = of.ofp_packet_out(data=packet.raw, in_port=in_port, actions=actions)
# #         log.info("Paquet DNS malveillant redirigé vers le honeypot.")
# #         datapath.send(msg)

# #     def forward_to_dns(self, datapath, packet, in_port):
# #         """Transmet le paquet au serveur DNS légitime."""
# #         actions = [of.ofp_action_output(port=of.OFPP_NORMAL)]
# #         msg = of.ofp_packet_out(data=packet.raw, in_port=in_port, actions=actions)
# #         log.info("Paquet DNS transmis au serveur DNS légitime.")
# #         datapath.send(msg)

# #     def parse_dns_packet(self, data):
# #         """Parse un paquet DNS."""
# #         try:
# #             dns = dpkt.dns.DNS(data)
# #             if dns.qr == dpkt.dns.DNS_R:  # Assurez-vous qu'il s'agit d'une réponse
# #                 return dns
# #         except (dpkt.UnpackError, ValueError) as e:
# #             log.error(f"Erreur de décodage du paquet DNS : {e}")
# #         return None

# #     def __del__(self):
# #         self.log_file.close()

# # def launch():
# #     core.registerNew(DNSMitigationController)



# #!/usr/bin/env python

# from pox.core import core
# import dpkt
# import random
# import time
# from pox.lib.packet import ethernet, ipv4, udp
# from pox.lib.addresses import IPAddr
# from pox.openflow import of

# log = core.getLogger()

# class DNSMitigationController(object):
#     def __init__(self):
#         core.openflow.addListeners(self)
#         self.honeypot_ip = IPAddr("10.0.0.4")  # IP du honeypot
#         self.honeypot_mac = "00:00:00:00:00:04"  # Adresse MAC du honeypot
#         self.dns_server_ip = IPAddr("10.0.0.3")  # IP du serveur DNS légitime
#         self.detection_accuracy = 0.9  # Précision de 90%
#         self.log_file = open('detection_log.txt', 'w')
#         self.log_file.write("Timestamp, TXID, PredictedLabel, ActualLabel, Decision\n")

#     def _handle_ConnectionUp(self, event):
#         """Ajoute des règles de flux lorsque le switch se connecte."""
#         log.info(f"Connection établie avec le switch {event.dpid}")

#         # Créer un match pour tout le trafic
#         match = of.ofp_match()
#         actions = [of.ofp_action_output(port=of.OFPP_NORMAL)]
        
#         # Créer une règle de flux
#         flow_mod = of.ofp_flow_mod()
#         flow_mod.match = match
#         flow_mod.idle_timeout = 10  # Timeout pour la règle de flux
#         flow_mod.actions = actions  # Assigner les actions

#         # Envoyer la règle de flux au switch
#         event.connection.send(flow_mod)

#     def _handle_PacketIn(self, event):
#         """Gère les paquets entrants dans le contrôleur POX."""
#         packet = event.parsed
#         in_port = event.port
#         datapath = event.connection

#         if not packet.parsed:
#             log.warning("Paquet ignoré (non parsé)")
#             return

#         udp_packet = packet.find('udp')
#         if udp_packet:
#             log.debug(f"Données UDP brutes : {bytes(udp_packet.payload)}")  # Affichez les données brutes
#             dns_pkt = self.parse_dns_packet(bytes(udp_packet.payload))
#             if dns_pkt:
#                 log.debug(f"Paquet DNS analysé : {dns_pkt}")
#             else:
#                 log.debug("Échec de l'analyse du paquet DNS")
#             return  # Quitter la méthode après traitement UDP

#         # Vérifie si le paquet est un paquet IPv4 et UDP avec une destination DNS
#         if isinstance(packet.next, ipv4) and packet.next.protocol == udp.UDP_PROTOCOL:
#             log.debug("Paquet UDP IPv4 reçu, vérification du port DNS.")
#             ip_packet = packet.next
#             udp_packet = ip_packet.next
#             if udp_packet.dstport == 53:  # Port DNS
#                 txid = dns_pkt.id  # Log TXID
#                 actual_label = self.get_actual_label(dns_pkt)
#                 predicted_label = self.classify_packet(actual_label)

#                 # Journalisation de la décision
#                 log.info(f"TXID: {txid}, Actual Label: {actual_label}, Predicted Label: {predicted_label}")
#                 if predicted_label == "malicious":
#                     self.redirect_to_honeypot(datapath, packet, in_port)
#                     decision = "redirected to honeypot"
#                 else:
#                     self.forward_to_dns(datapath, packet, in_port)
#                     decision = "forwarded to DNS"

#                 timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
#                 self.log_file.write(f"{timestamp}, {txid}, {predicted_label}, {actual_label}, {decision}\n")
#                 self.log_file.flush()
#             else:
#                 log.debug("Paquet UDP non destiné au port DNS (53).")

#     def get_actual_label(self, dns_pkt):
#         """Détermine si le paquet DNS est malveillant ou légitime."""
#         suspicious_ips = ["192.168.1.100", "10.0.0.99"]

#         if dns_pkt.an:
#             for answer in dns_pkt.an:
#                 decode_ip = dpkt.utils.inet_to_str(answer.ip)
#                 if decode_ip in suspicious_ips:
#                     return "malicious"
#         return "benign"

#     def classify_packet(self, actual_label):
#         """Classifie le paquet avec une précision de 90%."""
#         if actual_label == "malicious":
#             return "malicious" if random.random() < self.detection_accuracy else "benign"
#         else:
#             return "benign" if random.random() < self.detection_accuracy else "malicious"

#     def redirect_to_honeypot(self, datapath, packet, in_port):
#         """Redirige les paquets DNS malveillants vers le honeypot."""
#         # Modifier l'adresse IP de destination du paquet pour qu'il soit redirigé vers le honeypot
#         actions = [
#             of.ofp_action_dl_addr.set_dst(self.honeypot_mac),  # Adresse MAC du honeypot
#             of.ofp_action_nw_addr.set_dst(self.honeypot_ip),   # Adresse IP du honeypot
#             of.ofp_action_output(port=of.OFPP_NORMAL)
#         ]
#         msg = of.ofp_packet_out(data=packet.raw, in_port=in_port, actions=actions)
#         log.info("Paquet DNS malveillant redirigé vers le honeypot.")
#         datapath.send(msg)

#     def forward_to_dns(self, datapath, packet, in_port):
#         """Transmet le paquet au serveur DNS légitime."""
#         actions = [of.ofp_action_output(port=of.OFPP_NORMAL)]
#         msg = of.ofp_packet_out(data=packet.raw, in_port=in_port, actions=actions)
#         log.info("Paquet DNS transmis au serveur DNS légitime.")
#         datapath.send(msg)

#     def parse_dns_packet(self, data):
#         """Parse un paquet DNS."""
#         try:
#             dns = dpkt.dns.DNS(data)
#             if dns.qr == dpkt.dns.DNS_R:  # Assurez-vous qu'il s'agit d'une réponse
#                 return dns
#         except (dpkt.UnpackError, ValueError) as e:
#             log.error(f"Erreur de décodage du paquet DNS : {e}")
#         return None

#     def __del__(self):
#         self.log_file.close()

# def launch():
#     core.registerNew(DNSMitigationController)




#!/usr/bin/env python

from pox.core import core
import dpkt
import random
import time
from pox.lib.packet import ethernet, ipv4, udp
from pox.lib.addresses import IPAddr
from pox.openflow import of

log = core.getLogger()

class DNSMitigationController(object):
    def __init__(self):
        core.openflow.addListeners(self)
        self.honeypot_ip = IPAddr("10.0.0.4")  # IP du honeypot
        self.honeypot_mac = "00:00:00:00:00:04"  # Adresse MAC du honeypot
        self.dns_server_ip = IPAddr("10.0.0.3")  # IP du serveur DNS légitime
        self.detection_accuracy = 0.9  # Précision de 90%
        self.log_file = open('detection_log.txt', 'w')
        self.log_file.write("Timestamp, TXID, PredictedLabel, ActualLabel, Decision\n")

    def _handle_ConnectionUp(self, event):
        """Ajoute des règles de flux lorsque le switch se connecte."""
        log.info(f"Connection établie avec le switch {event.dpid}")

        # Créer un match pour tout le trafic
        match = of.ofp_match()
        actions = [of.ofp_action_output(port=of.OFPP_NORMAL)]
        
        # Créer une règle de flux
        flow_mod = of.ofp_flow_mod()
        flow_mod.match = match
        flow_mod.idle_timeout = 10  # Timeout pour la règle de flux
        flow_mod.actions = actions  # Assigner les actions

        # Envoyer la règle de flux au switch
        event.connection.send(flow_mod)

    def _handle_PacketIn(self, event):
        """Gère les paquets entrants dans le contrôleur POX."""
        packet = event.parsed
        in_port = event.port
        datapath = event.connection

        if not packet.parsed:
            log.warning("Paquet ignoré (non parsé)")
            return

        # Vérifie si le paquet est un paquet IPv4 et UDP avec une destination DNS
        if isinstance(packet.next, ipv4) and packet.next.protocol ==17:
            log.debug("Paquet UDP IPv4 reçu, vérification du port DNS.")
            ip_packet = packet.next
            udp_packet = ip_packet.next

            if udp_packet.dstport == 53:  # Port DNS
                dns_pkt = self.parse_dns_packet(udp_packet.payload)
                if dns_pkt:
                    txid = dns_pkt.id  # Log TXID
                    actual_label = self.get_actual_label(dns_pkt)
                    predicted_label = self.classify_packet(actual_label)

                    # Journalisation de la décision
                    log.info(f"TXID: {txid}, Actual Label: {actual_label}, Predicted Label: {predicted_label}")
                    if predicted_label == "malicious":
                        self.redirect_to_honeypot(datapath, packet, in_port)
                        decision = "redirected to honeypot"
                    else:
                        self.forward_to_dns(datapath, packet, in_port)
                        decision = "forwarded to DNS"

                    timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
                    self.log_file.write(f"{timestamp}, {txid}, {predicted_label}, {actual_label}, {decision}\n")
                    self.log_file.flush()
                else:
                    log.debug("Paquet DNS non valide ou non analysé correctement.")
            else:
                log.debug("Paquet UDP non destiné au port DNS (53).")

    def get_actual_label(self, dns_pkt):
        """Détermine si le paquet DNS est malveillant ou légitime."""
        suspicious_ips = ["192.168.1.100", "10.0.0.99"]

        if dns_pkt.an:
            for answer in dns_pkt.an:
                decode_ip = dpkt.utils.inet_to_str(answer.ip)
                if decode_ip in suspicious_ips:
                    return "malicious"
        return "benign"

    def classify_packet(self, actual_label):
        """Classifie le paquet avec une précision de 90%."""
        if actual_label == "malicious":
            return "malicious" if random.random() < self.detection_accuracy else "benign"
        else:
            return "benign" if random.random() < self.detection_accuracy else "malicious"

    def redirect_to_honeypot(self, datapath, packet, in_port):
        """Redirige les paquets DNS malveillants vers le honeypot."""
        actions = [
            of.ofp_action_dl_addr.set_dst(self.honeypot_mac),  # Adresse MAC du honeypot
            of.ofp_action_nw_addr.set_dst(self.honeypot_ip),   # Adresse IP du honeypot
            of.ofp_action_output(port=of.OFPP_NORMAL)
        ]
        msg = of.ofp_packet_out(data=packet.raw, in_port=in_port, actions=actions)
        log.info("Paquet DNS malveillant redirigé vers le honeypot.")
        datapath.send(msg)

    def forward_to_dns(self, datapath, packet, in_port):
        """Transmet le paquet au serveur DNS légitime."""
        actions = [of.ofp_action_output(port=of.OFPP_NORMAL)]
        msg = of.ofp_packet_out(data=packet.raw, in_port=in_port, actions=actions)
        log.info("Paquet DNS transmis au serveur DNS légitime.")
        datapath.send(msg)

    def parse_dns_packet(self, data):
        """Parse un paquet DNS."""
        try:
            dns = dpkt.dns.DNS(data)
            if dns.qr == dpkt.dns.DNS_R:  # Assurez-vous qu'il s'agit d'une réponse
                return dns
        except (dpkt.UnpackError, ValueError) as e:
            log.error(f"Erreur de décodage du paquet DNS : {e}")
        return None

    def __del__(self):
        self.log_file.close()

def launch():
    core.registerNew(DNSMitigationController)
