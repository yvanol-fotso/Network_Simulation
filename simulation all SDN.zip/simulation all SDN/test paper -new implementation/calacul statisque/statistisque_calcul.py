import math
from scipy.stats import binom_test

def calculate_ci(successes, n, confidence_level=0.95):
    """Calcule l'intervalle de confiance à un certain niveau."""
    p_hat = successes / n
    z = 1.96  # Z-score pour 95 % de confiance
    margin_of_error = z * math.sqrt((p_hat * (1 - p_hat)) / n)
    lower_bound = p_hat - margin_of_error
    upper_bound = p_hat + margin_of_error
    return lower_bound, upper_bound

def calculate_p_value(successes, n):
    """Calcule la p-value pour tester si les résultats sont significatifs."""
    p_value = binom_test(successes, n, 0.5, alternative='greater')
    return p_value

# Exemple d'utilisation
successes = 400  # Nombre de paquets détectés correctement
n = 500  # Taille de l'échantillon

# Calcul de l'intervalle de confiance
ci_lower, ci_upper = calculate_ci(successes, n)
print(f"Intervalle de confiance à 95 %: [{ci_lower:.3f}, {ci_upper:.3f}]")

# Calcul de la p-value
p_value = calculate_p_value(successes, n)
print(f"p-value: {p_value:.5f}")

# Vérifiez si les résultats sont significatifs
if p_value < 0.05:
    print("Les résultats sont statistiquement significatifs.")
else:
    print("Les résultats ne sont pas statistiquement significatifs.")
