# from scapy.all import *
# import time
# import random

# def is_valid_ip(address):
#     """ Vérifie si l'adresse IP est valide. """
#     try:
#         socket.inet_aton(address)
#         return True
#     except socket.error:
#         return False

# def generate_dns_traffic(dst_ip, qname, num_packets=500):
#     if not is_valid_ip(dst_ip):
#         print(f"Adresse IP invalide: {dst_ip}")
#         return
    
#     txid = 1000  # Initialisation du TXID
#     start_time = time.time()  # Début du temps pour mesurer la durée écoulée

#     # Liste des IPs suspects et légitimes
#     suspicious_ips = ["192.168.1.100", "10.0.0.99"]
#     legitimate_ips = ["93.184.216.34", "203.0.113.0"]

#     # Ouverture du fichier de log avec une structure améliorée
#     with open('dns_traffic_log.txt', 'w') as log_file:
#         log_file.write("Timestamp, TXID, Label, ElapsedTime(s)\n")  # En-tête du fichier de log

#         for i in range(num_packets):
#             # Déterminer aléatoirement si le paquet est malveillant ou bénin
#             label = "malicious" if random.choice([True, False]) else "benign"

#             # Construction du paquet DNS selon son type
#             if label == "malicious":
#                 dns_response = IP(dst=dst_ip)/UDP(dport=53)/DNS(
#                     id=txid,
#                     qr=1,  # Réponse
#                     aa=1,  # Réponse autoritaire
#                     qd=DNSQR(qname=qname),
#                     an=DNSRR(rrname=qname, ttl=86400, rdata=random.choice(suspicious_ips))  # IP suspecte
#                 )
#             else:
#                 dns_response = IP(dst=dst_ip)/UDP(dport=53)/DNS(
#                     id=txid,
#                     qr=1,  
#                     aa=1,  
#                     qd=DNSQR(qname=qname),
#                     an=DNSRR(rrname=qname, ttl=86400, rdata=random.choice(legitimate_ips))  # IP légitime
#                 )

#             send(dns_response, verbose=0)  # Envoi du paquet

#             # Calcul du temps écoulé
#             elapsed_time = round(time.time() - start_time, 3)  # Temps en secondes avec 3 décimales

#             # Enregistrement dans le fichier de log avec une structure claire
#             timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
#             log_file.write(f"{timestamp}, {txid}, {label}, {elapsed_time}\n")

#             txid += 1  # Incrémentation du TXID

# if __name__ == "__main__":
#     target_dns_resolver = "10.0.0.3"  # IP du résolveur DNS
#     generate_dns_traffic(target_dns_resolver, "www.example.com")  # Génération du trafic


###########################################################################

# from scapy.all import *
# import time
# import random
# import socket  # Assurez-vous d'importer le module socket

# def is_valid_ip(address):
#     """ Vérifie si l'adresse IP est valide. """
#     try:
#         socket.inet_aton(address)
#         return True
#     except socket.error:
#         return False

# def generate_dns_traffic(dst_ip, qname, num_packets=500):
#     if not is_valid_ip(dst_ip):
#         print(f"Adresse IP invalide: {dst_ip}")
#         return
    
#     txid = 1000  # Initialisation du TXID
#     start_time = time.time()  # Début du temps pour mesurer la durée écoulée

#     # Liste des IPs suspects et légitimes
#     suspicious_ips = ["192.168.1.100", "10.0.0.99"]
#     legitimate_ips = ["93.184.216.34", "203.0.113.0"]

#     # Ouverture du fichier de log avec une structure améliorée
#     with open('dns_traffic_log.txt', 'w') as log_file:
#         log_file.write("Timestamp, TXID, Label, ElapsedTime(s), rdata\n")  # En-tête du fichier de log

#         for i in range(num_packets):
#             # Déterminer aléatoirement si le paquet est malveillant ou bénin
#             label = "malicious" if random.choice([True, False]) else "benign"

#             # Déterminer l'adresse IP à utiliser
#             if label == "malicious":
#                 rdata = random.choice(suspicious_ips)  # IP suspecte
#             else:
#                 rdata = random.choice(legitimate_ips)  # IP légitime

#             # Construction du paquet DNS selon son type
#             dns_response = IP(dst=dst_ip)/UDP(dport=53)/DNS(
#                 id=txid,
#                 qr=1,  # Réponse
#                 aa=1,  # Réponse autoritaire
#                 qd=DNSQR(qname=qname),
#                 an=DNSRR(rrname=qname, ttl=86400, rdata=rdata)  # IP choisie
#             )

#             send(dns_response, verbose=0)  # Envoi du paquet

#             # Calcul du temps écoulé
#             elapsed_time = round(time.time() - start_time, 3)  # Temps en secondes avec 3 décimales

#             # Enregistrement dans le fichier de log avec une structure claire
#             timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
#             log_file.write(f"{timestamp}, {txid}, {label}, {elapsed_time}, {rdata}\n")  # Ajout de rdata

#             txid += 1  # Incrémentation du TXID

# if __name__ == "__main__":
#     target_dns_resolver = "10.0.0.3"  # IP du résolveur DNS
#     generate_dns_traffic(target_dns_resolver, "www.example.com")  # Génération du trafic




################### rend l'adresse ip visible pour eveider le decodage cote controlleur #################


from scapy.all import *
import time
import random
import socket

def is_valid_ip(address):
    """Vérifie si l'adresse IP est valide."""
    try:
        socket.inet_aton(address)
        return True
    except socket.error:
        return False

def generate_dns_traffic(dst_ip, qname, num_packets=500):
    if not is_valid_ip(dst_ip):
        print(f"Adresse IP invalide: {dst_ip}")
        return
    
    txid = 1000  # Initialisation du TXID
    start_time = time.time()  # Début du temps pour mesurer la durée écoulée

    # Liste des IPs suspects et légitimes
    suspicious_ips = ["192.168.1.100", "10.0.0.99"]
    legitimate_ips = ["93.184.216.34", "203.0.113.0"]

    # Ouverture du fichier de log avec une structure améliorée
    with open('dns_traffic_log.txt', 'w') as log_file:
        log_file.write("Timestamp, TXID, Label, ElapsedTime(s), rdata\n")  # En-tête du fichier de log

        for i in range(num_packets):
            # Déterminer aléatoirement si le paquet est malveillant ou bénin
            label = "malicious" if random.choice([True, False]) else "benign"

            # Déterminer l'adresse IP à utiliser
            #rdata = socket.inet_aton(random.choice(suspicious_ips) if label == "malicious" else random.choice(legitimate_ips))  # IP en format binaire
            rdata = random.choice(suspicious_ips) if label == "malicious" else random.choice(legitimate_ips)  # IP en format

            # Construction du paquet DNS selon son type
            dns_response = IP(dst=dst_ip)/UDP(dport=53)/DNS(
                id=txid,
                qr=1,  # Réponse
                aa=1,  # Réponse autoritaire
                qd=DNSQR(qname=qname),
                an=DNSRR(rrname=qname, ttl=86400, rdata=rdata)  # IP choisie
            )

            send(dns_response, verbose=0)  # Envoi du paquet

            # Calcul du temps écoulé
            elapsed_time = round(time.time() - start_time, 3)  # Temps en secondes avec 3 décimales

            # Enregistrement dans le fichier de log avec une structure claire
            timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
            #log_file.write(f"{timestamp}, {txid}, {label}, {elapsed_time}, {socket.inet_ntoa(rdata)}\n")  # Ajout de rdata

            log_file.write(f"{timestamp}, {txid}, {label}, {elapsed_time}, {rdata}\n")  # Ajout de rdata
            
            txid += 1  # Incrémentation du TXID

if __name__ == "__main__":
    target_dns_resolver = "10.0.0.3"  # IP du résolveur DNS
    generate_dns_traffic(target_dns_resolver, "www.example.com")  # Génération du trafic
