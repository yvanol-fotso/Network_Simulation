import matplotlib.pyplot as plt

def read_traffic_log(filename):
    """Lit le fichier de trafic DNS et retourne les timestamps classés par type."""
    benign_times = []
    malicious_times = []
    
    with open(filename, 'r') as file:
        for line in file:
            timestamp, packet_type = line.strip().split(', ')
            if packet_type == "benign":
                benign_times.append(float(timestamp))
            elif packet_type == "malicious":
                malicious_times.append(float(timestamp))
    
    return benign_times, malicious_times

def plot_dns_traffic(benign_times, malicious_times):
    """Trace les courbes pour les paquets bénins et malveillants."""
    plt.figure(figsize=(10, 6))

    # Courbe des paquets bénins
    plt.plot(benign_times, range(1, len(benign_times) + 1), label='Bénins', color='green', marker='o')
    plt.text(benign_times[-1], len(benign_times), f"{len(benign_times)}", 
             color='green', fontsize=12, ha='left', va='bottom')

    # Courbe des paquets malveillants
    plt.plot(malicious_times, range(1, len(malicious_times) + 1), label='Malveillants', color='red', marker='x')
    plt.text(malicious_times[-1], len(malicious_times), f"{len(malicious_times)}", 
             color='red', fontsize=12, ha='left', va='bottom')

    # Configuration du graphique
    plt.xlabel("Temps (timestamp UNIX)")
    plt.ylabel("Nombre de paquets")
    plt.title("Visualisation du nombre de paquets DNS bénins et malveillants au fil du temps")
    plt.legend()
    plt.grid(True)

    # Affiche le graphique
    plt.show()

if __name__ == "__main__":
    # Lire les données depuis le fichier
    benign, malicious = read_traffic_log('dns_traffic_log.txt')
    
    # Tracer le graphique
    plot_dns_traffic(benign, malicious)
