# import seaborn as sns
# import matplotlib.pyplot as plt
# import pandas as pd

# def read_traffic_log(filename):
#     """Reads the DNS traffic log file and returns a DataFrame."""
#     data = {'timestamp': [], 'packet_type': []}
    
#     with open(filename, 'r') as file:
#         for line in file:
#             timestamp, packet_type = line.strip().split(', ')
#             data['timestamp'].append(float(timestamp))
#             data['packet_type'].append(packet_type)
    
#     return pd.DataFrame(data)

# def plot_dns_traffic(df):
#     """Plots DNS traffic with benign and malicious packets over time."""
#     # Create a cumulative count for each packet type
#     df['count'] = 1
#     df['cumulative_count'] = df.groupby('packet_type')['count'].cumsum()

#     # Plot using Seaborn
#     sns.set(style="whitegrid")
#     plt.figure(figsize=(12, 6))
    
#     sns.lineplot(
#         data=df, 
#         x='timestamp', 
#         y='cumulative_count', 
#         hue='packet_type', 
#         style='packet_type',
#         markers=True, 
#         dashes=False, 
#         palette={'benign': 'green', 'malicious': 'red'}
#     )

#     # Display the total count at the end of each curve
#     for packet_type, group in df.groupby('packet_type'):
#         final_point = group.iloc[-1]
#         plt.text(
#             final_point['timestamp'], 
#             final_point['cumulative_count'], 
#             f"{len(group)}", 
#             color='green' if packet_type == 'benign' else 'red', 
#             fontsize=12, 
#             ha='left', 
#             va='center'
#         )

#     # Set plot labels and title
#     plt.xlabel("Time (UNIX timestamp)")
#     plt.ylabel("Cumulative Packet Count")
#     plt.title("Cumulative DNS Traffic: Benign vs Malicious Packets")
#     plt.legend(title='Packet Type')
    
#     # Show the plot
#     plt.show()

# if __name__ == "__main__":
#     # Load data from the log file
#     df = read_traffic_log('dns_traffic_log.txt')
    
#     # Plot the DNS traffic
#     plot_dns_traffic(df)




import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

def read_traffic_log(filename):
    """Reads the DNS traffic log file and returns a DataFrame."""
    data = {'timestamp': [], 'packet_type': []}
    
    with open(filename, 'r') as file:
        for line in file:
            timestamp, packet_type = line.strip().split(', ')
            data['timestamp'].append(float(timestamp))
            data['packet_type'].append(packet_type)
    
    return pd.DataFrame(data)

def plot_dns_traffic(df):
    """Plots DNS traffic with benign and malicious packets over time."""
    # Create a cumulative count for each packet type
    df['count'] = 1
    df['cumulative_count'] = df.groupby('packet_type')['count'].cumsum()

    # Set the aesthetic style of the plots
    sns.set_style("white")  # Use 'white' to remove grid lines and set a clean background
    plt.figure(figsize=(12, 6))
    
    # Plot using Seaborn
    sns.lineplot(
        data=df, 
        x='timestamp', 
        y='cumulative_count', 
        hue='packet_type', 
        style='packet_type',
        markers=True, 
        dashes=False, 
        palette={'benign': 'green', 'malicious': 'red'}
    )

    # Display the total count at the end of each curve
    for packet_type, group in df.groupby('packet_type'):
        final_point = group.iloc[-1]
        plt.text(
            final_point['timestamp'], 
            final_point['cumulative_count'], 
            f"{len(group)}", 
            color='green' if packet_type == 'benign' else 'red', 
            fontsize=12, 
            ha='left', 
            va='center'
        )

    # Set plot labels and title
    plt.xlabel("Time (UNIX timestamp)", fontsize=14)
    plt.ylabel("Cumulative Packet Count", fontsize=14)
    plt.title("Cumulative DNS Traffic: Benign vs Malicious Packets", fontsize=16)
    plt.legend(title='Packet Type', fontsize=12)

    # Optionally remove the spines (the border lines)
    sns.despine()

    # Show the plot
    plt.show()

if __name__ == "__main__":
    # Load data from the log file
    df = read_traffic_log('dns_traffic_log.txt')
    
    # Plot the DNS traffic
    plot_dns_traffic(df)
