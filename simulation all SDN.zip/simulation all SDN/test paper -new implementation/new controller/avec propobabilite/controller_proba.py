import dpkt
import random
import time
import math
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER, set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet, ethernet, ipv4, udp

class DNSMitigationController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(DNSMitigationController, self).__init__(*args, **kwargs)
        self.log_file = open('detection_log.txt', 'w')
        self.honeypot_ip = "10.0.0.4"
        self.redirection_probability = 0.7
        self.detection_accuracy = 0.8

        # Initialisation des statistiques de détection
        self.total_packets = 0
        self.detected_attacks = 0
        self.false_positives = 0
        self.false_negatives = 0
        self.true_positives = 0
        self.true_negatives = 0

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        """Configuration initiale du switch."""
        datapath = ev.msg.datapath
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        # Flux par défaut : envoyer tous les paquets au contrôleur
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, ofproto.OFPCML_NO_BUFFER)]
        self.add_flow(datapath, 0, match, actions)

        # Flux pour le trafic ARP
        match_arp = parser.OFPMatch(eth_type=0x0806)
        actions_arp = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match_arp, actions_arp)

        # Flux pour le trafic ICMP
        match_icmp = parser.OFPMatch(eth_type=0x0800, ip_proto=1)
        actions_icmp = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match_icmp, actions_icmp)

    def add_flow(self, datapath, priority, match, actions, buffer_id=None):
        """Ajouter une règle de flux au switch."""
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        mod = parser.OFPFlowMod(datapath=datapath, priority=priority, match=match, 
                                instructions=inst, buffer_id=buffer_id or ofproto.OFP_NO_BUFFER)
        datapath.send_msg(mod)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        """Gestion des paquets entrants."""
        start_time = time.time()
        msg = ev.msg
        datapath = msg.datapath
        parser = datapath.ofproto_parser

        in_port = msg.match['in_port']

        print(f"Received packet from datapath {datapath.id} on port {in_port}")

        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocols(ethernet.ethernet)[0]

        if eth.ethertype == 0x0800:  # IPv4
            ip = pkt.get_protocols(ipv4.ipv4)[0]
            if ip.proto == 17:  # UDP
                udp_pkt = pkt.get_protocols(udp.udp)[0]
                if udp_pkt.dst_port == 53:  # DNS
                    dns_pkt = self.parse_dns_packet(msg.data)
                    if dns_pkt and dns_pkt.qr == 1:
                        self.total_packets += 1
                        txid = dns_pkt.id
                        is_attack = self.is_dns_attack(txid)

                        detection_result = self.simulate_detection(is_attack)
                        detection_time = time.time() - start_time

                        # Mise à jour des statistiques
                        if detection_result == "malicious":
                            self.true_positives += 1
                            if random.random() < self.redirection_probability:
                                self.redirect_to_honeypot(datapath, in_port, msg.data)
                        elif detection_result == "false_positive":
                            self.false_positives += 1
                        elif detection_result == "false_negative":
                            self.false_negatives += 1
                        else:
                            self.true_negatives += 1

                        self.log_detection(txid, detection_result, detection_time)

    def parse_dns_packet(self, data):
        """Analyse un paquet DNS."""
        try:
            eth = dpkt.ethernet.Ethernet(data)
            ip = eth.data
            udp = ip.data
            dns = dpkt.dns.DNS(udp.data)
            return dns
        except dpkt.UnpackError:
            return None

    def is_dns_attack(self, txid):
        """Détection basée sur TXID entre 1000 et 1099."""
        return 1000 <= txid <= 1500

    def simulate_detection(self, is_attack):
        """Simulation avec faux positifs/négatifs."""
        prob = random.random()
        if is_attack:
            return "malicious" if prob < self.detection_accuracy else "false_negative"
        else:
            return "false_positive" if prob < (1 - self.detection_accuracy) else "benign"

    def redirect_to_honeypot(self, datapath, in_port, data):
        """Redirige le paquet vers le honeypot."""
        parser = datapath.ofproto_parser
        actions = [parser.OFPActionSetField(ipv4_dst=self.honeypot_ip),
                   parser.OFPActionOutput(datapath.ofproto.OFPP_NORMAL)]
        out = parser.OFPPacketOut(datapath=datapath, buffer_id=0xffffffff,
                                  in_port=in_port, actions=actions, data=data)
        datapath.send_msg(out)

    def log_detection(self, txid, result, detection_time):
        """Log de la détection."""
        current_time = time.time()
        self.log_file.write(f"{current_time}, TXID: {txid}, Result: {result}, "
                            f"Detection Time: {detection_time:.6f}s\n")
        self.log_file.flush()

    def calculate_statistics(self):
        """Calcul des statistiques."""
        precision = self.true_positives / (self.true_positives + self.false_positives)
        recall = self.true_positives / (self.true_positives + self.false_negatives)

        z = 1.96  # Intervalle de confiance à 95%
        proportion = self.detected_attacks / self.total_packets
        ci = z * math.sqrt(proportion * (1 - proportion) / self.total_packets)

        print(f"Précision: {precision:.2f}, Rappel: {recall:.2f}")
        print(f"IC à 95 %: [{proportion - ci:.3f}, {proportion + ci:.3f}]")

    def __del__(self):
        """Fermeture du fichier log."""
        self.log_file.close()

