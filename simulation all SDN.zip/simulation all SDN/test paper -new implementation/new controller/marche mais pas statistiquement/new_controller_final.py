import dpkt
import random
import time
import math
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER, set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet, ethernet, ipv4, udp

class DNSMitigationController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(DNSMitigationController, self).__init__(*args, **kwargs)
        self.log_file = open('detection_log.txt', 'w')
        self.honeypot_ip = "10.0.0.4"
        self.redirection_probability = 0.7  # 70% de redirection vers le honeypot
        self.detection_accuracy = 0.8  # 80% de précision
        self.total_packets = 0
        self.detected_attacks = 0
        self.false_positives = 0
        self.false_negatives = 0

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        parser = datapath.ofproto_parser

        # Règle par défaut : envoyer tous les paquets au contrôleur
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(datapath.ofproto.OFPP_CONTROLLER)]
        self.add_flow(datapath, 0, match, actions)

    def add_flow(self, datapath, priority, match, actions, buffer_id=None):
        parser = datapath.ofproto_parser
        inst = [parser.OFPInstructionActions(datapath.ofproto.OFPIT_APPLY_ACTIONS, actions)]
        mod = parser.OFPFlowMod(datapath=datapath, priority=priority, match=match, instructions=inst)
        datapath.send_msg(mod)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        start_time = time.time()
        msg = ev.msg
        datapath = msg.datapath
        pkt = packet.Packet(msg.data)
        eth = pkt.get_protocols(ethernet.ethernet)[0]

        # Ignorer les paquets LLDP pour éviter les boucles de découverte
        if eth.ethertype == 0x88cc:
            return

        if eth.ethertype == 0x0800:  # IPv4
            ip = pkt.get_protocols(ipv4.ipv4)[0]
            if ip.proto == 17:  # UDP
                udp_pkt = pkt.get_protocols(udp.udp)[0]
                if udp_pkt.dst_port == 53:  # DNS
                    dns_pkt = self.parse_dns_packet(msg.data)
                    if dns_pkt and dns_pkt.qr == 1:  # Réponse DNS
                        self.total_packets += 1
                        txid = dns_pkt.id
                        is_malicious = self.is_dns_attack(txid)

                        detection_result = self.simulate_detection(is_malicious)
                        detection_time = time.time() - start_time

                        if detection_result == "malicious":
                            self.detected_attacks += 1
                            if random.random() < self.redirection_probability:
                                self.redirect_to_honeypot(datapath, ev.msg.in_port, msg.data)
                        elif detection_result == "false_positive":
                            self.false_positives += 1
                        elif detection_result == "false_negative":
                            self.false_negatives += 1

                        self.log_detection(txid, detection_result, detection_time)

    def parse_dns_packet(self, data):
        eth = dpkt.ethernet.Ethernet(data)
        ip = eth.data
        udp = ip.data
        try:
            dns = dpkt.dns.DNS(udp.data)
            return dns
        except dpkt.UnpackError:
            return None

    def is_dns_attack(self, txid):
        """Détection simplifiée : attaque si TXID entre 1000 et 1500."""
        return 1000 <= txid <= 1500

    def simulate_detection(self, is_attack):
        """Simule la détection avec faux positifs et négatifs."""
        prob = random.random()
        if is_attack:
            return "malicious" if prob < self.detection_accuracy else "false_negative"
        else:
            return "false_positive" if prob < (1 - self.detection_accuracy) else "benign"

    def redirect_to_honeypot(self, datapath, in_port, data):
        parser = datapath.ofproto_parser
        actions = [parser.OFPActionSetField(ipv4_dst=self.honeypot_ip),
                   parser.OFPActionOutput(datapath.ofproto.OFPP_NORMAL)]
        out = parser.OFPPacketOut(datapath=datapath, buffer_id=0xffffffff,
                                  in_port=in_port, actions=actions, data=data)
        datapath.send_msg(out)

    def log_detection(self, txid, result, detection_time):
        """Journalise les détections avec timestamp et résultats."""
        current_time = time.time()
        self.log_file.write(f"{current_time}, TXID: {txid}, Result: {result}, Time: {detection_time:.6f}s\n")
        self.log_file.flush()

    def calculate_statistics(self):
        """Calcule les métriques : précision, rappel, CI."""
        precision = self.detected_attacks / (self.detected_attacks + self.false_positives)
        recall = self.detected_attacks / (self.detected_attacks + self.false_negatives)

        z = 1.96  # Z-score pour 95 % de confiance
        proportion = self.detected_attacks / self.total_packets
        ci = z * math.sqrt(proportion * (1 - proportion) / self.total_packets)

        print(f"Précision: {precision:.2f}, Rappel: {recall:.2f}")
        print(f"Intervalle de confiance (95 %): [{proportion - ci:.3f}, {proportion + ci:.3f}]")

    def __del__(self):
        self.log_file.close()
