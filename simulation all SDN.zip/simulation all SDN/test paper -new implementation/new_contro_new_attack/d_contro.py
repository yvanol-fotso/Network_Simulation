import dpkt
import random
import time
import math
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, CONFIG_DISPATCHER, set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet, ethernet, ipv4, udp

class DNSMitigationController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(DNSMitigationController, self).__init__(*args, **kwargs)
        self.honeypot_ip = "10.0.0.4"  # IP du honeypot
        self.dns_server_ip = "10.0.0.3"  # IP du serveur DNS légitime
        self.detection_accuracy = 0.9  # Précision de 90%
        self.log_file = open('detection_log.txt', 'w')
        self.log_file.write("Timestamp, TXID, PredictedLabel, ActualLabel, Decision\n")

    # @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    # def switch_features_handler(self, ev):
    #     """Initialise les flux du switch."""
    #     datapath = ev.msg.datapath
    #     parser = datapath.ofproto_parser
    #     ofproto = datapath.ofproto

    #     # Règle par défaut : Envoyer tous les paquets au contrôleur
    #     match = parser.OFPMatch()
    #     actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, ofproto.OFPCML_NO_BUFFER)]
    #     self.add_flow(datapath, 0, match, actions)


    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        """Configuration initiale du switch."""
        datapath = ev.msg.datapath
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        # Flux par défaut : envoyer tous les paquets au contrôleur
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER, ofproto.OFPCML_NO_BUFFER)]
        self.add_flow(datapath, 0, match, actions)

        # Flux pour le trafic ARP
        match_arp = parser.OFPMatch(eth_type=0x0806)
        actions_arp = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match_arp, actions_arp)

        # Flux pour le trafic ICMP
        match_icmp = parser.OFPMatch(eth_type=0x0800, ip_proto=1)
        actions_icmp = [parser.OFPActionOutput(ofproto.OFPP_NORMAL)]
        self.add_flow(datapath, 1, match_icmp, actions_icmp)


    def add_flow(self, datapath, priority, match, actions):
        """Ajoute une règle de flux au switch."""
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto
        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        mod = parser.OFPFlowMod(datapath=datapath, priority=priority, match=match, instructions=inst)
        datapath.send_msg(mod)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        """Gère les paquets entrants."""
        msg = ev.msg
        datapath = msg.datapath
        in_port = msg.match['in_port']
        pkt = packet.Packet(msg.data)

        eth = pkt.get_protocol(ethernet.ethernet)
        if eth.ethertype == 0x0800:  # IPv4
            ip = pkt.get_protocol(ipv4.ipv4)
            if ip.proto == 17:  # UDP
                udp_pkt = pkt.get_protocol(udp.udp)
                if udp_pkt.dst_port == 53:  # DNS
                    dns_pkt = self.parse_dns_packet(msg.data)
                    if dns_pkt and dns_pkt.qr == 1:  # Réponse DNS
                        actual_label = "malicious" if 1000 <= dns_pkt.id <= 1500 else "benign"
                        predicted_label = self.classify_packet(actual_label)

                        # Décision en fonction de la classification
                        if predicted_label == "malicious":
                            self.redirect_to_honeypot(datapath, in_port, msg.data)
                            decision = "redirected to honeypot"
                        else:
                            self.forward_to_dns(datapath, in_port, msg.data)
                            decision = "forwarded to DNS"

                        # Log de la décision
                        timestamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
                        self.log_file.write(
                            f"{timestamp}, {dns_pkt.id}, {predicted_label}, {actual_label}, {decision}\n"
                        )
                        self.log_file.flush()

    def classify_packet(self, actual_label):
        """Classifie le paquet avec une précision de 90%."""
        if actual_label == "malicious":
            return "malicious" if random.random() < self.detection_accuracy else "benign"
        else:
            return "benign" if random.random() < self.detection_accuracy else "malicious"

    # def parse_dns_packet(self, data):
    #     """Analyse un paquet DNS."""
    #     pkt = packet.Packet(data)
    #     udp_pkt = pkt.get_protocol(udp.udp)
    #     if udp_pkt:
    #         dns_pkt = pkt.get_protocol(dns.dns)
    #         return dns_pkt
    #     return None



    #import dpkt  # Import dpkt pour l’analyse DNS

    def parse_dns_packet(self, data):
        """Analyse un paquet DNS avec dpkt."""
        eth = dpkt.ethernet.Ethernet(data)  # Décodage du paquet Ethernet
        if isinstance(eth.data, dpkt.ip.IP):
           ip_pkt = eth.data
           if isinstance(ip_pkt.data, dpkt.udp.UDP):
              udp_pkt = ip_pkt.data
              if udp_pkt.dport == 53:  # Vérifie si c'est un paquet DNS
                 try:
                    dns_pkt = dpkt.dns.DNS(udp_pkt.data)
                    return dns_pkt
                 except (dpkt.UnpackError, ValueError):
                    self.logger.error("Erreur de décodage du paquet DNS.")
        return None


    # def redirect_to_honeypot(self, datapath, in_port, data):
    #     """Redirige le paquet vers le honeypot."""
    #     parser = datapath.ofproto_parser
    #     actions = [
    #         parser.OFPActionSetField(ipv4_dst=self.honeypot_ip),
    #         parser.OFPActionOutput(datapath.ofproto.OFPP_NORMAL)
    #     ]
    #     out = parser.OFPPacketOut(datapath=datapath, in_port=in_port, actions=actions, data=data)
    #     datapath.send_msg(out)

    def redirect_to_honeypot(self, datapath, in_port, data):
        """Redirige le paquet vers le honeypot."""
        parser = datapath.ofproto_parser
        actions = [
             parser.OFPActionSetField(ipv4_dst=self.honeypot_ip),
             parser.OFPActionOutput(datapath.ofproto.OFPP_NORMAL)
        ]
        out = parser.OFPPacketOut(
            datapath=datapath,
            buffer_id=datapath.ofproto.OFP_NO_BUFFER,  # Ajout du buffer_id
            in_port=in_port,
            actions=actions,
            data=data
        )
        datapath.send_msg(out)


    # def forward_to_dns(self, datapath, in_port, data):
    #     """Transmet le paquet au serveur DNS légitime."""
    #     parser = datapath.ofproto_parser
    #     actions = [
    #         parser.OFPActionSetField(ipv4_dst=self.dns_server_ip),
    #         parser.OFPActionOutput(datapath.ofproto.OFPP_NORMAL)
    #     ]
    #     out = parser.OFPPacketOut(datapath=datapath, in_port=in_port, actions=actions, data=data)
    #     datapath.send_msg(out)


    def forward_to_dns(self, datapath, in_port, data):
        """Transmet le paquet au serveur DNS légitime."""
        parser = datapath.ofproto_parser
        actions = [
           parser.OFPActionSetField(ipv4_dst=self.dns_server_ip),
           parser.OFPActionOutput(datapath.ofproto.OFPP_NORMAL)
        ]
        out = parser.OFPPacketOut(
            datapath=datapath,
            buffer_id=datapath.ofproto.OFP_NO_BUFFER,  # Ajout du buffer_id
            in_port=in_port,
            actions=actions,
            data=data
        )
        datapath.send_msg(out)


    def __del__(self):
        """Ferme le fichier log."""
        self.log_file.close()
